"""
God Mode Package

This package contains the God Mode Trader for the QMP Overrider system.
"""

from .god_trader import execute_divine_trades

__all__ = ['execute_divine_trades']
