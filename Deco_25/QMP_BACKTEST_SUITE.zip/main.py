
from AlgorithmImports import *

class QMPBacktestSuite(QCAlgorithm):
    def Initialize(self):
        self.SetStartDate(2022, 1, 1)
        self.SetEndDate(2023, 1, 1)
        self.SetCash(100000)
        self.SetBrokerageModel(BrokerageName.InteractiveBrokersBrokerage)

        self.AddCrypto("BTCUSD", Resolution.Second)
        self.AddCrypto("ETHUSD", Resolution.Second)
        self.AddForex("EURUSD", Resolution.Minute)
        self.AddForex("USDJPY", Resolution.Minute)
        self.AddEquity("SPY", Resolution.Minute)
        self.AddCfd("XAUUSD", Resolution.Minute)

        self.lastAction = None

    def OnData(self, data):
        if not self.Portfolio.Invested and data.ContainsKey("SPY") and data["SPY"].Price > 0:
            self.SetHoldings("SPY", 0.1)
